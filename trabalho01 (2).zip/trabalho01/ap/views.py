from django.shortcuts import redirect, render
from .models import Contato, Servico, Categoria
from .forms import FormContato, FormServico

# Create your views here.

def index(request):
    return render (request, "index.html")

def servicos(request):
    
    ## servicos = Servico.objects.all()
    servicos = Servico.objects.filter(ativo=True)
    servicos = servicos.exclude(preco=0)   
     
    total_servicos = servicos.count()
    tem_servicos = servicos.exists()
    
    mais_barato = servicos.order_by('preco').first()
    mais_caro = servicos.order_by('-preco').first()
    
    
    #recupera o valor do formulário de busca enviado pelo usuário
    busca = request.GET.get('busca')
    if busca:
        servicos = servicos.filter(nome__icontains=busca)
        
    #recupera as categorias ativas para exibir no filtro
    categorias = Categoria.objects.filter(ativo=True)
    
    #recupera o valor do filtro de categoria enviado pelo usuário
    categoria = request.GET.get('categoria')
    if categoria:
        #aplica o filtro de categoria aos serviços
        servicos = servicos.filter(categoria_id=categoria)
        
    preco = request.GET.get('preco')
    if preco == 'baixo':
        servicos = servicos.filter(preco__lte=50)
    elif preco == 'medio':
        servicos = servicos.filter(preco__gt=50, preco__lte=250)
    elif preco == 'alto':
        servicos = servicos.filter(preco__gt=250)
    
    ordem = request.GET.get('ordem')
    if ordem == 'menor':
        servicos = servicos.order_by('preco')
    elif ordem == 'maior':
        servicos = servicos.order_by('-preco')
    elif ordem == 'nome':
        servicos = servicos.order_by('nome')

    contexto = {
        'servicos': servicos,
        'total_servicos': total_servicos,
        'tem_servicos': tem_servicos,
        'mais_barato': mais_barato,
        'mais_caro': mais_caro,
        'busca': busca,
        'categoria': categoria,
        'categorias': categorias,
        'preco': preco,
        'ordem' : ordem,
    }
        
    return render (request, "servicos.html", contexto)

def addServico(request):
    form = FormServico(request.POST or None, request.FILES or None)
    if request.method == "POST":
        if form.is_valid():
            form.save()
            return redirect('servicos')

    return render (request, "add-servico.html", {'form': form})

def excluirServico(request, id):
    servico = Servico.objects.get(id=id)
    servico.imagem.delete(save=False)
    servico.delete()
    return redirect('servicos')

def editarServico(request, id):
    servico = Servico.objects.get(id=id)
    form = FormServico(request.POST or None, request.FILES or None, instance=servico)
    if request.POST:
        if form.is_valid():
            form.save()
            return redirect('servicos')

    return render (request, "editar-servico.html", {'form': form})

def produtos(request):
    servicos = Servico.objects.all()
    return render(request, "produtos.html", {'servicos': servicos})

def contatos(request):
    contatos = Contato.objects.all()
    return render(request, "contatos.html", {'contatos': contatos})

def novoContato(request):
    if request.method == "POST":
        form = FormContato(request.POST)
        if form.is_valid():
            form.save()
            return redirect('index')
    else:
        form = FormContato()
    
    return render(request, "novo-contato.html", {'form': form})

def excluirContato(request, id):
    contato = Contato.objects.get(id=id)
    contato.delete()
    return redirect('contatos')